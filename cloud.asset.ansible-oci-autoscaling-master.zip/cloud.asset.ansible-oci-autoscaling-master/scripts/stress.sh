stress --cpu 4 --timeout 1500
