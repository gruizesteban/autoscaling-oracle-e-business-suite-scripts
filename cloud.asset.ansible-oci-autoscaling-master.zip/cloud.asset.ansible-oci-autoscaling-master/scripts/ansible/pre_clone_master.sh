#/bin/sh

#Copyright © 2018, Oracle and/or its affiliates. All rights reserved.
#The Universal Permissive License (UPL), Version 1.0

export ANSIBLE_CONFIG=./ansible.cfg
export ANSIBLE_HOST_KEY_CHECKING=False
ansible-playbook preclone_master.yml -i inventory -vvv